# Peer Discovery UDP — Ngô Đặng Minh Khôi

## Nhiệm vụ

Module này phụ trách **Peer Discovery UDP** cho ứng dụng Chat P2P.

### Chức năng

- UDP Broadcast để tìm các máy trong cùng mạng LAN.
- Nhận `DISCOVER_PEER`.
- Trả `PEER_INFO`.
- Lưu `peer_id`, username, IP và TCP port.
- Gửi discovery định kỳ để duy trì trạng thái online.
- Xóa peer nếu không còn heartbeat trong thời gian timeout.
- Có callback để Peer Management/GUI sử dụng.

## File

- `peer_discovery.py`: module chính.
- `test_peer_discovery.py`: test module.
- `peer_discovery_demo.py`: chương trình demo 1 máy.

## Chạy test

```bash
python test_peer_discovery.py
```

Kết quả mong đợi:

```text
TEST 1 - insert/update peer: PASS
TEST 2 - receive PEER_INFO: PASS
TEST 3 - ignore own packet: PASS
TEST 4 - remove expired peer: PASS

ALL PEER DISCOVERY TESTS: PASS
```

## Chạy demo

Trên Windows:

```bash
python peer_discovery_demo.py
```

Mở chương trình trên **2 máy cùng mạng LAN**. Nếu Windows Firewall hỏi quyền truy cập mạng, cho phép Python trên mạng Private.

Mỗi máy sẽ tự gửi:

```json
{
  "type": "DISCOVER_PEER",
  "peer_id": "...",
  "username": "Khoi",
  "tcp_port": 5000
}
```

Peer nhận được sẽ trả:

```json
{
  "type": "PEER_INFO",
  "peer_id": "...",
  "username": "Tai",
  "tcp_port": 5000
}
```

## Kiến trúc

```text
              UDP Broadcast
                    |
                    v
             +-------------+
             | PeerDiscovery|
             +-------------+
                    |
          +---------+---------+
          |                   |
          v                   v
    DISCOVER_PEER         PEER_INFO
          |                   |
          +---------+---------+
                    |
                    v
              Peer list
                    |
                    v
             Peer Management
                    |
             +------+------+
             |             |
             v             v
          TCP Chat     File Transfer
```

## Lưu ý

Module này **không thay thế phần TCP Chat** và không sửa `client.py`/`server.py`.
Lý do: Peer Discovery là nhiệm vụ riêng của Developer; việc chuyển toàn bộ project từ client-server hiện tại sang P2P TCP cần được Team Lead và Network Developer ghép với nhau.

README của project mô tả kiến trúc cuối cùng là:

**LAN UDP Discovery → TCP direct connection → Chat/File Transfer.**
