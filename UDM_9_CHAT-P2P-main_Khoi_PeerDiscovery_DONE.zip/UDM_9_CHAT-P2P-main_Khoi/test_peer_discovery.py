import socket
import time

from peer_discovery import PeerDiscovery


def test_peer_insert_and_update():
    discovery = PeerDiscovery(
        username="Khôi",
        tcp_port=5000,
        peer_id="peer-khoi",
    )

    discovery._upsert_peer(
        peer_id="peer-tai",
        username="Tài",
        ip="192.168.1.10",
        tcp_port=5001,
    )

    peers = discovery.get_peers()

    assert len(peers) == 1
    assert peers[0].username == "Tài"
    assert peers[0].ip == "192.168.1.10"
    assert peers[0].tcp_port == 5001

    old_time = peers[0].last_seen

    time.sleep(0.01)

    discovery._upsert_peer(
        peer_id="peer-tai",
        username="Tài Updated",
        ip="192.168.1.11",
        tcp_port=5002,
    )

    peer = discovery.get_peer("peer-tai")

    assert peer is not None
    assert peer.username == "Tài Updated"
    assert peer.ip == "192.168.1.11"
    assert peer.tcp_port == 5002
    assert peer.last_seen > old_time

    print("TEST 1 - insert/update peer: PASS")


def test_packet_handling():
    discovered = []

    discovery = PeerDiscovery(
        username="Khôi",
        tcp_port=5000,
        peer_id="peer-khoi",
        on_peer_discovered=lambda peer: discovered.append(peer),
    )

    packet = (
        b'{"type":"PEER_INFO","peer_id":"peer-tai",'
        b'"username":"Tai","tcp_port":5001}'
    )

    discovery._handle_packet(packet, ("192.168.1.10", 37020))

    assert len(discovered) == 1
    assert discovered[0].peer_id == "peer-tai"
    assert discovered[0].ip == "192.168.1.10"

    print("TEST 2 - receive PEER_INFO: PASS")


def test_self_packet_is_ignored():
    discovery = PeerDiscovery(
        username="Khôi",
        tcp_port=5000,
        peer_id="peer-khoi",
    )

    packet = (
        b'{"type":"PEER_INFO","peer_id":"peer-khoi",'
        b'"username":"Khoi","tcp_port":5000}'
    )

    discovery._handle_packet(packet, ("192.168.1.20", 37020))

    assert len(discovery.get_peers()) == 0

    print("TEST 3 - ignore own packet: PASS")


def test_expired_peer():
    removed = []

    discovery = PeerDiscovery(
        username="Khôi",
        tcp_port=5000,
        peer_id="peer-khoi",
        peer_timeout=0.01,
        on_peer_removed=lambda peer: removed.append(peer),
    )

    discovery._upsert_peer(
        peer_id="peer-tai",
        username="Tài",
        ip="192.168.1.10",
        tcp_port=5001,
    )

    time.sleep(0.03)
    discovery._remove_expired_peers()

    assert len(discovery.get_peers()) == 0
    assert len(removed) == 1

    print("TEST 4 - remove expired peer: PASS")


if __name__ == "__main__":
    test_peer_insert_and_update()
    test_packet_handling()
    test_self_packet_is_ignored()
    test_expired_peer()

    print("\nALL PEER DISCOVERY TESTS: PASS")
