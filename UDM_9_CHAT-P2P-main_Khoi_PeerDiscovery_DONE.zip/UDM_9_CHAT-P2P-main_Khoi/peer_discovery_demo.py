import time

from peer_discovery import PeerDiscovery


USERNAME = input("Nhập tên của bạn: ").strip() or "Khoi"
TCP_PORT = 5000


def on_discovered(peer):
    print(
        f"\n[+] Peer mới: {peer.username} | "
        f"{peer.ip}:{peer.tcp_port}"
    )


def on_updated(peer):
    print(
        f"\n[*] Peer cập nhật: {peer.username} | "
        f"{peer.ip}:{peer.tcp_port}"
    )


def on_removed(peer):
    print(
        f"\n[-] Peer offline: {peer.username} | "
        f"{peer.ip}:{peer.tcp_port}"
    )


discovery = PeerDiscovery(
    username=USERNAME,
    tcp_port=TCP_PORT,
    on_peer_discovered=on_discovered,
    on_peer_updated=on_updated,
    on_peer_removed=on_removed,
)

try:
    discovery.start()

    print("\nPeer Discovery UDP đang chạy.")
    print("Port UDP:", discovery.discovery_port)
    print("Nhấn Ctrl+C để dừng.\n")

    while True:
        time.sleep(2)

        peers = discovery.get_peers()

        print("\n--- DANH SÁCH PEER ---")
        if not peers:
            print("Chưa phát hiện peer nào.")
        else:
            for peer in peers:
                print(
                    f"{peer.username:15} "
                    f"{peer.ip}:{peer.tcp_port} "
                    f"id={peer.peer_id}"
                )

except KeyboardInterrupt:
    print("\nĐang dừng...")

finally:
    discovery.stop()
    print("Peer Discovery đã dừng.")
